export type Cars = {
  id: number;
  model: String;
  brand: String;
  year: number;
};
