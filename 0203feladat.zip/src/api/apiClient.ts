import axios from "axios";

const apiClient = axios.create({
  baseURL: "surveys-5jvt.onrender.com/api",
});

export default apiClient;
 