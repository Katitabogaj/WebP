import React, { useEffect, useState } from "react";
import apiClient from "../api/apiClient";
import { error } from "console";
import { Cars } from "../types/cars";

function Get() {
  const [data, setData] = useState(Array<Cars>);

  useEffect(() => {
    apiClient
      .get("/cars")
      .then((response) => {
        setData(response.data);
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);
  return (
    <div className="App">
      <header className="App-header">
        <p>
          Edit <code>src/App.tsx</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        ></a>
      </header>
      <table>
        <th>id</th>
        <th>brand</th>
        <th>model</th>
        <th>year</th>
        {data.map((sz) => (
          <tr>
            <td>{sz.brand}</td>
            <td>{sz.model}</td>
            <td>{sz.year}</td>
            <td>{sz.id}</td>
          </tr>
        ))}
      </table>
    </div>
  );
}

export default Get;
