document.addEventListener('DOMContentLoaded', () => {

    const kartyalista = [
        {
            name: 'metallica',
            image: 'meta.png'
        },
        {
            name: 'metallica',
            image: 'meta.png'
        },
        {
            name: 'kiss',
            image: 'kiss.png'
        },
        {
            name: 'kiss',
            image: 'kiss.png'
        },
        {
            name: 'ACDC',
            image: 'ACDC.png'
        },
        {
            name: 'ACDC',
            image: 'ACDC.png'
        },
        {
            name: 'AWS',
            image: 'AWS.png'
        },
        {
            name: 'AWS',
            image: 'AWS.png'
        },
        {
            name: 'lp',
            image: 'lp.png'
        },
        {
            name: 'lp',
            image: 'lp.png'
        },
        {
            name: 'nirvana',
            image: 'nirvana.png'
        },
        {
            name: 'nirvana',
            image: 'nirvana.png'
        },
        {
            name: 'slipknot',
            image: 'slip.png'
        },
        {
            name: 'slipknot',
            image: 'slip.png'
        },
        {
            name: 'ledzeppelin',
            image: 'zeppelin.png'
        },
        {
            name: 'ledzeppelin',
            image: 'zeppelin.png'
        }
    ];
    
    kartyalista.sort( () => 0.5 - Math.random() ); //véletlen sorrend

    const grid = document.querySelector('.jgrid');

    const probakt = document.querySelector('.probak');  //Számláló összekapcsolása
    const megtalaltt = document.querySelector('.megtalalt');
    const osszkartya = 8;
 
    var probakak = 0;
    var megtalaltak = 0;
    probakt.textContent = probakak; //Számláló értékei
    megtalaltt.textContent = megtalaltak;

    var valasztottak = [];
    var valasztottakID = [];
 

    function letrehoz() {
        for (var i =0; i < kartyalista.length; i++) {   //Kártyák létrehozása és képek hozzárendelése
            var kartya = document.createElement('img');
            kartya.setAttribute('src', 'hatso.png');
            kartya.setAttribute('data-id', i);
            kartya.addEventListener('click', forditas);
            grid.appendChild(kartya);   //minden képhez tarozzon kártya
        }
    }

    function forditas() {
        if (valasztottak.length != 2){ //ne lehessen 2-nél több kártyára kattintani
            var kartyaid = this.getAttribute('data-id');
            if (this.getAttribute('src') != 'ures.png'){
                valasztottak.push(kartyalista[kartyaid].name); //tőmbben tárolja a kártyák nevét és ID-ját
                valasztottakID.push(kartyaid);
                this.setAttribute('src', kartyalista[kartyaid].image); 
                if(valasztottak.length == 2) {
                setTimeout(ellenorzes, 400);
                }
            }
        }
    }

    function ellenorzes(){
        probakak++;
        var kartyak = document.querySelectorAll('img');
        var elsokartya = valasztottakID[0];
        var masodikkartya = valasztottakID[1];
        if(valasztottak[0] == valasztottak[1])
        {
            megtalaltak++;
            kartyak[elsokartya].setAttribute('src', 'ures.png');
            kartyak[masodikkartya].setAttribute('src', 'ures.png');
        }
        else {
            kartyak[elsokartya].setAttribute('src', 'hatso.png');
            kartyak[masodikkartya].setAttribute('src', 'hatso.png');
        }
        valasztottak = [];
        valasztottakID = [];
        probakt.textContent = probakak;
        megtalaltt.textContent = megtalaltak;
        if(megtalaltak == osszkartya){
            alert('Gratulálok! Jobb vagy mint egy átlag 3 éves.');
            setTimeout(ujra, 5000)
        }
    }
    function ujra ()
    {
        window.location.reload();
    }

    letrehoz();
})